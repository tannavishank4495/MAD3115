//
//  HomeCell.swift
//  GalaxyCinemas
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class HomeCell: UITableViewCell {

    @IBOutlet weak var imgTheatre: UIImageView!
    
    @IBOutlet weak var lblTheatreName: UILabel!
    
    @IBOutlet weak var lblTheatreLocation: UILabel!
    
    @IBOutlet weak var lblAddress: UILabel!

    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
