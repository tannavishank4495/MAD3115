//
//  MovieList.swift
//  GalaxyCinemas
//
//  Created by MacStudent on 2018-08-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class MovieList{
    
    
    static var MovieTitle : [String] = ["Dynamic", "Justice Maharaja", "Lazer", "Vaastav", "WelcomeToNewYork"]
    static var  MovieImages : [String] = ["Dynamic", "JusticeMaharaja", "Lazer", "Vaastav", "WelcomeToNewYork"]
    
    
    
}
