//
//  Items.swift
//  GalaxyCinemas
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Items{
    
    
    static var TheatreName : [String] = ["Galaxy1", "GalaxyLafa", "Galaxy8", "GalaxyStarplex", "Galaxy Theatre"]
    static var TheatreLoaction :[String] = ["6917 EL Camino Real Unit I, ", "121 East Alessandro Blvd, ","631 N Indiana St.","2525 Patterson Rd.","1575 RetherFord Street," ]
    static var TheatreImages : [String] = ["Galaxy1", "GalaxyLafa", "Galaxy8", "GalaxyStarplex", "Galaxytheater"]
    static var Address :[String] = ["Atascadero,CA 92508","RiverSide, CA 93422","PoretrVille,CA 93257","RiverBank,CA 95367","Tulare,CA 93274" ]
    
    
    
}
