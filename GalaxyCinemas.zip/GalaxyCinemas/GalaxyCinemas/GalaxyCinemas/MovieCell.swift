//
//  MovieCell.swift
//  GalaxyCinemas
//
//  Created by MacStudent on 2018-08-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class MovieCell: UITableViewCell {

    @IBOutlet weak var txtDesc: UITextView!
    
    @IBOutlet weak var Date: UIDatePicker!
    
    @IBOutlet weak var lblMovieTitle: UILabel!
    
    @IBOutlet weak var imgMovies: UIImageView!
    
    @IBAction func btn1(_ sender: UIButton) {
     
    }
    
    
    @IBAction func btn2(_ sender: UIButton) {
    
    }
    
    @IBAction func btn3(_ sender: UIButton) {
    }
    
    @IBAction func btn4(_ sender: Any) {
    }
    
    
    @IBAction func btn5(_ sender: Any) {
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    

}
