//
//  ViewController.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-03.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txtName: UITextField!
    
    @IBOutlet var lblName: UILabel!
    
    @IBAction func btnGreet(_ sender: UIButton) {
        lblName.isHidden = false
        lblName.text = txtName.text
        
        print("Name : \(String(describing: lblName.text))")
        
        let nameAlert = UIAlertController(title: "Name", message: lblName.text, preferredStyle: .actionSheet)
        nameAlert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))
        nameAlert.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
        nameAlert.addAction(UIAlertAction(title: "Don't bother me", style: .destructive, handler: nil))
        nameAlert.addAction(UIAlertAction(title: "Don't bother me", style: .default, handler: nil))
        
        self.present(nameAlert,animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        lblName.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

